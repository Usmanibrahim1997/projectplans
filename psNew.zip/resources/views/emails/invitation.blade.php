<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>You have been invited to join our site!</title>
</head>
<body>
    <h1>You have been invited to join our site!</h1>
    <p>Hi there,</p>
    <p>You have been invited to join our site. Please follow the link below to create your account:</p>
    <p><a href="{{ $url }}">{{ $url }}</a></p>
    <p>Thank you for joining us!</p>
</body>
</html>
