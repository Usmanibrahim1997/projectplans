@extends('admin.partials.head')
@section('content')
@include('admin.partials.header')
@endsection

    
    
      
        
    